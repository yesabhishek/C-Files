/*To Find The Number Is Even Or odd*/
#include<stdio.h>
#include,conio.h>
void main()
{
	int i;
	printf("\n\nTo Find the number is even or odd");
	printf("\n\nEnter the number ");
	scanf("%d",&i);
	if(i%2==0)
	{
		printf("\nNumber is EVEN");
	}
	else
	{
		printf("\nNumber is ODD");
	}
	getch();

}