#include<stdio.h>
#include<conio.h>
void main()
{
int mat1[50][50],mat2[50][50],i,j,temp,n,n1,n2,n3;
clrscr();
printf("enter the dimension of matrix");
scanf("%d%d",&n,&n1);
printf("\enter the matrix");
for(i=0;i<n;i++)
{
for(j=0;j<n1;j++)
{
scanf("%d",&mat1[i][j]);
}
}
printf("\n\n the matrix is :");
for(i=0;i<n;i++)
{
printf("\n");
for(j=0;j<n1;j++)
{
printf("%d\t",mat1[i][j]);
}
}
printf("\n");
printf("\n the transpose of matrix is");
for(i=0;i<n;i++)
{
printf("\n");
for(j=0;j<n1;j++)
{
printf("%d\t",mat1[j][i]);
}
}
getch();
}


